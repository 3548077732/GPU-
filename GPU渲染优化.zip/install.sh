SKIPMOUNT=false
LATESTARTSERVICE=false
POSTFSDATA=false
PROPFILE=true

# 获取设备型号
device_model=$(getprop ro.product.model)

echo "Device model ($DEVICE MODEL) 机型检测正常！"
ui_print ""
ui_print ""

print_modname() {
 ui_print "*******************************"
 ui_print "*******************************"
 ui_print "酷安@Redmi2023"
 ui_print "*******************************"
 ui_print "*********添加一些优化*********"
}

on_install() {
 ui_print "正在释放文件...."
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 ui_print ""
 ui_print ""

 sleep 1

 ui_print "重启后生效"
}

set_permissions() {
 set_perm_recursive $MODPATH 0 0 0777 0777
#设置权限，基本不要去动
}
